document.getElementById("contactForm").addEventListener("submit", function(e) {
  e.preventDefault();
  alert("Xabaringiz yuborildi!");
});

document.getElementById("registerForm").addEventListener("submit", function(e) {
  e.preventDefault();
  alert("Kirish muvaffaqiyatli!");
});