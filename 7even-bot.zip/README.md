# 7EVEN Bot

This is a simple Discord bot built for 7EVEN to get the Active Developer badge.

## Features
- `!ping` command to check if the bot is running

## Deploy Instructions (iOS compatible via browser)
1. Create a GitHub repo and upload all files from this zip.
2. Go to [Railway](https://railway.app) and log in.
3. Create a new project → Deploy from GitHub → Select your repo.
4. Go to the `Variables` tab → Add new variable:
   - Key: TOKEN
   - Value: your bot token
5. Wait for the bot to deploy → Invite it to your server
6. Send `!ping` in your Discord server. It should reply `Pong!`
